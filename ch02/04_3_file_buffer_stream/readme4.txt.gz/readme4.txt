저를 writem3.txt로 보내주세요
